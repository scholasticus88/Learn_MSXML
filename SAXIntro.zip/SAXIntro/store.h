#pragma once 

#include "Book.h"
#include "CD.h"

class Store
{
	std::vector<Book>	books;
	std::vector<CD>		cds;
public:
	Store() {}

	void AddBook(Book book) {books.push_back(book);}
	void AddCD(CD cd) {cds.push_back(cd);}

	std::wstring ToString() const
	{
		std::wstringstream sstr;
		for(std::vector<Book>::const_iterator itb = books.begin();
			itb != books.end(); ++itb)
		{
			sstr << (*itb).ToString() << L'\n';
		}

		sstr << L'\n';

		for(std::vector<CD>::const_iterator itc = cds.begin();
			itc != cds.end(); ++itc)
		{
			sstr << (*itc).ToString() << L'\n';
		}

		return sstr.str();
	}
};