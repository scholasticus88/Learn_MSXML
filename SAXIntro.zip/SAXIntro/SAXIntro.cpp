// SAXIntro.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#ifdef _DEBUG
#include <vld.h>
#endif

#include "store.h"

#include "SAXStore.h"
#include "SAXErrorHandlerImpl.h"

#include <iomanip>

int wmain(int argc, wchar_t* argv[])
{
	if (argc<2) 
	{
		wprintf(L"no argument provided\n");
		return 0;
	}

	// initialize COM library for the current thread
	CoInitialize(NULL); 
	ISAXXMLReader* pXMLReader = NULL;

	// create an instance of the XML reader
	HRESULT hr = CoCreateInstance(
		__uuidof(SAXXMLReader), 
		NULL, 
		CLSCTX_ALL, 
		__uuidof(ISAXXMLReader), 
		(void **)&pXMLReader);

	if(!FAILED(hr)) 
	{
		// create a new content handler
		SAXStore *pStoreHandler = new SAXStore();
		// register the content handler with the reader
		hr = pXMLReader->putContentHandler(pStoreHandler);
		// create a new error handler
		SAXErrorHandlerImpl * pErrorHandler = new SAXErrorHandlerImpl();
		// register the error handler with the reader
		hr = pXMLReader->putErrorHandler(pErrorHandler);

		std::wcout << L"Parsing document: " << argv[1] << std::endl << std::endl;
		// parse the document
		hr = pXMLReader->parseURL(argv[1]);
		if(!FAILED(hr))
		{
			// display the items in the store
			std::wcout << pStoreHandler->GetStore().ToString() << std::endl;
		}
		else
		{
			std::wcout << L"\nParse result code: " << std::setbase(std::ios_base::hex) << hr << std::endl << std::endl;
		}

		// destroy the XML reader
		pXMLReader->Release();
	}
	else 
	{
		std::wcout << L"\nParse result code: " << std::setbase(std::ios_base::hex) << hr << std::endl << std::endl;
	}

	// un-itialize the COM library for this threads
	CoUninitialize();

	return 0;
}

