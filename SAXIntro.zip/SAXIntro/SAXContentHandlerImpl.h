#pragma once

class SAXContentHandlerImpl : public ISAXContentHandler  
{
	long m_RefCount;
public:
	SAXContentHandlerImpl():m_RefCount(0) {}
	virtual ~SAXContentHandlerImpl() {}

	long __stdcall QueryInterface(const struct _GUID &riid, void ** ppObj)
		{ 
			if (riid == IID_IUnknown)
			{
				*ppObj = static_cast<IUnknown*>(this);
			}
			if (riid == __uuidof(ISAXContentHandler))
			{
				*ppObj = static_cast<ISAXContentHandler*>(this);
			}
			else
			{
				*ppObj = NULL ;
				return E_NOINTERFACE ;
			}

			AddRef() ;
			return S_OK;
		}
	unsigned long __stdcall AddRef(void)
		{
			return InterlockedIncrement(&m_RefCount);
		}
	unsigned long __stdcall Release(void)
		{
			long nRefCount=0;
			nRefCount=InterlockedDecrement(&m_RefCount) ;
			if (nRefCount == 0) delete this;
			return nRefCount;
		}

	virtual HRESULT STDMETHODCALLTYPE putDocumentLocator( 
			ISAXLocator __RPC_FAR *pLocator)
		{return S_OK;}

	virtual HRESULT STDMETHODCALLTYPE startDocument( void)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE endDocument( void)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE startPrefixMapping( 
			wchar_t __RPC_FAR *pwchPrefix,
			int cchPrefix,
			wchar_t __RPC_FAR *pwchUri,
			int cchUri)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE endPrefixMapping( 
			wchar_t __RPC_FAR *pwchPrefix,
			int cchPrefix)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE startElement( 
			wchar_t __RPC_FAR *pwchNamespaceUri,
			int cchNamespaceUri,
			wchar_t __RPC_FAR *pwchLocalName,
			int cchLocalName,
			wchar_t __RPC_FAR *pwchRawName,
			int cchRawName,
			ISAXAttributes __RPC_FAR *pAttributes)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE endElement( 
			wchar_t __RPC_FAR *pwchNamespaceUri,
			int cchNamespaceUri,
			wchar_t __RPC_FAR *pwchLocalName,
			int cchLocalName,
			wchar_t __RPC_FAR *pwchRawName,
			int cchRawName)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE characters( 
			wchar_t __RPC_FAR *pwchChars,
			int cchChars)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE ignorableWhitespace( 
			wchar_t __RPC_FAR *pwchChars,
			int cchChars)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE processingInstruction( 
			wchar_t __RPC_FAR *pwchTarget,
			int cchTarget,
			wchar_t __RPC_FAR *pwchData,
			int cchData)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE skippedEntity( 
			wchar_t __RPC_FAR *pwchName,
			int cchName)
		{return S_OK;}
};
