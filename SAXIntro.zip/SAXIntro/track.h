#pragma once 

#include <string>
#include <sstream>

class Track 
{
	std::wstring	title_;
	std::wstring	length_;
public:
	Track() {}
	Track(std::wstring title, std::wstring length):title_(title), length_(length) {}

	void SetTitle(std::wstring title) {title_ = title;}
	void SetLength(std::wstring length) {length_ = length;}

	std::wstring ToString() const
	{
		std::wstringstream sstr;
		sstr << title_ << L", " << length_;
		return sstr.str();
	}
};