#pragma once 

#include "track.h"
#include <vector>

class CD
{
	std::wstring		title_;
	std::wstring		artist_;
	std::vector<Track>	tracks_;
public:
	CD() {}

	void SetTitle(std::wstring title) {title_ = title;}
	void SetArtist(std::wstring artist) {artist_ = artist;}
	void AddTrack(Track track) {tracks_.push_back(track);}

	std::wstring ToString() const
	{
		std::wstringstream sstr;
		sstr << L"\'" << title_ << L"', " << artist_ << L'\n';
		int i = 1;
		for(std::vector<Track>::const_iterator it = tracks_.begin();
			it != tracks_.end(); ++ it)
		{
			sstr << L"  " << i++ << L". " << (*it).ToString() << L'\n';
		}

		return sstr.str();
	}
};