#pragma once

class SAXErrorHandlerImpl : public ISAXErrorHandler  
{
	long m_RefCount;
public:
	SAXErrorHandlerImpl():m_RefCount(0) {}
	virtual ~SAXErrorHandlerImpl() {}

	long __stdcall QueryInterface(const struct _GUID &riid, void ** ppObj)
	{
		if (riid == IID_IUnknown)
		{
			*ppObj = static_cast<IUnknown*>(this);
		}
		if (riid == __uuidof(ISAXErrorHandler))
		{
			*ppObj = static_cast<ISAXErrorHandler*>(this);
		}
		else
		{
			*ppObj = NULL ;
			return E_NOINTERFACE ;
		}

		AddRef() ;
		return S_OK;
	}
	unsigned long __stdcall AddRef(void)
	{
		return InterlockedIncrement(&m_RefCount);
	}
	unsigned long __stdcall Release(void)
	{
		long nRefCount=0;
		nRefCount=InterlockedDecrement(&m_RefCount) ;
		if (nRefCount == 0) delete this;
		return nRefCount;
	}

	virtual HRESULT STDMETHODCALLTYPE error( 
			ISAXLocator __RPC_FAR *pLocator,
			unsigned short * pwchErrorMessage,
			HRESULT errCode) 
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE fatalError( 
			ISAXLocator __RPC_FAR *pLocator,
			unsigned short * pwchErrorMessage,
			HRESULT errCode)
		{return S_OK;}
        
	virtual HRESULT STDMETHODCALLTYPE ignorableWarning( 
			ISAXLocator __RPC_FAR *pLocator,
			unsigned short * pwchErrorMessage,
			HRESULT errCode)
		{return S_OK;}
};
