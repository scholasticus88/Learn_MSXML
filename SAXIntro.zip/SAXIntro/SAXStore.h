#pragma once
#include "saxcontenthandlerimpl.h"

#include "store.h"
#include <stack>

enum ElemType {SIgnore, SStore, SBook, SCD};

struct StackElement
{
	StackElement(void* element, ElemType elemtype = SIgnore):
		type(elemtype), data(element)
	{
	}

	ElemType	type;
	void*		data;
};

class SAXStore :
	public SAXContentHandlerImpl
{
	Store store_;

	std::stack<StackElement>	elements;
	bool						hasText;

public:
	SAXStore(void);
	virtual ~SAXStore(void);

	Store GetStore() const {return store_;}

	virtual HRESULT STDMETHODCALLTYPE startElement( 
		wchar_t __RPC_FAR *pwchNamespaceUri,
		int cchNamespaceUri,
		wchar_t __RPC_FAR *pwchLocalName,
		int cchLocalName,
		wchar_t __RPC_FAR *pwchRawName,
		int cchRawName,
		ISAXAttributes __RPC_FAR *pAttributes);

	virtual HRESULT STDMETHODCALLTYPE endElement( 
		wchar_t __RPC_FAR *pwchNamespaceUri,
		int cchNamespaceUri,
		wchar_t __RPC_FAR *pwchLocalName,
		int cchLocalName,
		wchar_t __RPC_FAR *pwchRawName,
		int cchRawName);

	virtual HRESULT STDMETHODCALLTYPE characters( 
		wchar_t __RPC_FAR *pwchChars,
		int cchChars);

	std::wstring GetAttributeValue(ISAXAttributes __RPC_FAR *pAttributes,
		std::wstring name, std::wstring defvalue);
};
