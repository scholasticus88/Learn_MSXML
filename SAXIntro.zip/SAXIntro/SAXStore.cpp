#include "StdAfx.h"
#include "saxstore.h"

SAXStore::SAXStore(void)
:hasText(false)
{
}

SAXStore::~SAXStore(void)
{
}

HRESULT STDMETHODCALLTYPE SAXStore::startElement( 
	wchar_t __RPC_FAR *pwchNamespaceUri,
	int cchNamespaceUri,
	wchar_t __RPC_FAR *pwchLocalName,
	int cchLocalName,
	wchar_t __RPC_FAR *pwchRawName,
	int cchRawName,
	ISAXAttributes __RPC_FAR *pAttributes)
{
	// assume element does not have text
	hasText = false;
	// take the local name
	std::wstring localName(pwchLocalName);

	// test the element's name and take appropriate action
	if(localName.compare(L"store") == 0)
	{
		elements.push(StackElement(new Store, SStore));
	}
	else if(localName.compare(L"book") == 0)
	{
		elements.push(StackElement(new Book(GetAttributeValue(pAttributes, L"isbn", L"unknown")),SBook) );
	}
	else if(localName.compare(L"cd") == 0)
	{
		elements.push(StackElement(new CD(), SCD));
	}
	else if(localName.compare(L"track") == 0)
	{
		elements.push(StackElement(new std::wstring(GetAttributeValue(pAttributes, L"length", L"0.00"))));
		elements.push(StackElement(new std::wstring()));
		// tracks have text
		hasText = true;
	}
	else if(localName.compare(L"title") == 0 || localName.compare(L"author") == 0 || 
		localName.compare(L"artist") == 0)
	{
		// all elements have text
		elements.push(StackElement(new std::wstring()));
		hasText = true;
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE SAXStore::endElement( 
	wchar_t __RPC_FAR *pwchNamespaceUri,
	int cchNamespaceUri,
	wchar_t __RPC_FAR *pwchLocalName,
	int cchLocalName,
	wchar_t __RPC_FAR *pwchRawName,
	int cchRawName)
{
	// reset flag, at this point data is consumed
	hasText = false;
	// take the data from the stack's top
	StackElement elem = elements.top();
	// pop the element at the top
	elements.pop();
	// take the local name
	std::wstring localName(pwchLocalName);
	// check the name of the element and take appropriate action
	if(localName.compare(L"store") == 0)
	{
		store_ = *(Store*)elem.data;
		delete (Store*)elem.data;
	}
	else if(localName.compare(L"book") == 0)
	{
		((Store*)elements.top().data)->AddBook(*(Book*)elem.data);
		delete (Book*)elem.data;
	}
	else if(localName.compare(L"cd") == 0)
	{
		((Store*)elements.top().data)->AddCD(*(CD*)elem.data);
		delete (CD*)elem.data;
	}
	else if(localName.compare(L"track") == 0)
	{
		// take the length from the stack
		std::wstring* len = (std::wstring*)elements.top().data;
		// pop the element at the top
		elements.pop();
		// add the track to the CD
		((CD*)elements.top().data)->AddTrack(Track(*(std::wstring*)elem.data, *len));

		delete (std::wstring*)elem.data;
		delete (std::wstring*)len;
	}
	else if(localName.compare(L"title") == 0)
	{
		// check whether the current element is a book or a CD
		switch(elements.top().type)
		{
		case SBook:
			((Book*)elements.top().data)->SetTitle(*(std::wstring*)elem.data);
			break;
		case SCD:
			((CD*)elements.top().data)->SetTitle(*(std::wstring*)elem.data);
			break;
		}

		delete (std::wstring*)elem.data;
	}
	else if(localName.compare(L"author") == 0)
	{
		((Book*)elements.top().data)->SetAuthor(*(std::wstring*)elem.data);
		delete (std::wstring*)elem.data;
	}
	else if(localName.compare(L"artist") == 0)
	{
		((CD*)elements.top().data)->SetArtist(*(std::wstring*)elem.data);
		delete (std::wstring*)elem.data;
	}
	else
	{
		// put data back to the stack
		elements.push(elem);
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE SAXStore::characters( 
	wchar_t __RPC_FAR *pwchChars,
	int cchChars)
{
	if(hasText)
	{
		// append current text to the existing text
		std::wstring* top = (std::wstring*)elements.top().data;
		std::wstring text(pwchChars, cchChars);
		*top += text;
	}
	else
	{
		// data which is not part of recognized element
	}

	return S_OK;
}

std::wstring SAXStore::GetAttributeValue(ISAXAttributes __RPC_FAR *pAttributes,
							   std::wstring name, std::wstring defvalue)
{
	// get the number of attributes
	int length = 0;
	pAttributes->getLength(&length);

	// enumerate over all attributes
	for ( int i=0; i<length; i++ ) 
	{
		wchar_t *attrname = NULL, * attrvalue = NULL;
		int namelen = 0, valuelen = 0;

		// get the local name of the current attribute
		pAttributes->getLocalName(i,&attrname,&namelen);
		// get the value of the current attribute
		pAttributes->getValue(i,&attrvalue,&valuelen);
		// if current attribute is the one needed return its value
		if(name.compare(std::wstring(attrname,namelen)) == 0)
			return std::wstring(attrvalue, valuelen);
	}

	// attribute not found; return the default value
	return defvalue;
}
