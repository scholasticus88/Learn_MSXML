#pragma once 

#include <string>
#include <sstream>

class Book
{
	std::wstring	title_;
	std::wstring	author_;
	std::wstring	isbn_;
public:
	Book() {}
	Book(std::wstring isbn) {isbn_ = isbn;}

	void SetTitle(std::wstring title) {title_ = title;}
	void SetAuthor(std::wstring author) {author_ = author;}
	void SetIsbn(std::wstring isbn) {isbn_ = isbn;}

	std::wstring ToString() const
	{
		std::wstringstream sstr;
		sstr << L"\'" << title_ << L"\' by " << author_ << L", ISBN: " << isbn_;
		return sstr.str();
	}
};
